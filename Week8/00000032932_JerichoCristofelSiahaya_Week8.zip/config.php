<?php

$databaseHost = 'localhost';
$databaseName = 'unimedia_senin';
$databaseUsername = 'root';
$databasePassword = '';

$conn = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
