<?php
header("Location: produk_list.php");
