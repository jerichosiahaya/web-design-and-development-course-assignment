<?php
header("Location: upload_form.php");
